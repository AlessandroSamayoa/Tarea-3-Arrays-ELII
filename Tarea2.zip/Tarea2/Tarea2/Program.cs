﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea2
{
    class Program
    {
        static void Main(string[] args){
            bool exit = true;
            int[] arr5 = new int[10];
            do { 
                try {
                    bool flag = true;
                    while (flag == true) {
                        int opcion = menu();
                        switch (opcion) {
                            //Nombres de los alumnos
                            case 1:
                                bool flag2 = true;
                                while (flag2) {
                                    clear();
                                    imprimir();
                                    flag2 = salir();
                                }
                                break;
                            //Ingreso de las notas
                            case 2:
                                bool flag3 = true;
                                while (flag3) { 
                                    clear();
                                    imprimir();
                                    Console.WriteLine("\nIngrese el nombre del estudiante para ingresar las notas");
                                    Console.Write("\t>>>Estudiante: ");
                                    string name = Console.ReadLine();
                                    int j = 0;
                                    int count = 0;
                                    string[] array2 = estudiantes();
                                    while (!name.Equals(array2[j]))
                                    {
                                        j++;
                                        count++;
                                        if (j >= array2.Length)
                                        {
                                            break;
                                        }
                                    }
                                    if (j >= array2.Length)
                                    {
                                        Console.WriteLine("\nEste nombre no existe, ENTER para regresar");
                                        int salir = int.Parse(Console.ReadLine());
                                    }
                                    clear();
                                    Console.WriteLine("conteo: " + count);
                                    int save = 0, datos = 0, promedio = 0, k = 1;
                                    Console.WriteLine("\tAlumn@: >>>" + name);
                                    Console.WriteLine("\t------------------------");
                                    do {
                                        try {
                                            Console.Write("Porfavor ingrese la nota " + k + ": >>> ");
                                                datos = int.Parse(Console.ReadLine());
                                                save += datos;
                                                k++;
                                        } catch {
                                            menError();
                                        }
                                    } while (k!=6);
                                    promedio = save / 5;
                                    clear();
                                    Console.WriteLine("\tAlumn@: >>>" + name);
                                    Console.WriteLine("\t------------------------");
                                    Console.WriteLine("El promedio de las 5 notas ingresadas es: >>> " + promedio);
                                    
                                    arr5[count] = promedio;
                                    flag3 = salir();
                                }
                                break;
                            //Ver notas
                            case 3:
                                bool flag4 = true;
                                while (flag4)
                                {
                                    clear();
                                    Console.WriteLine("\tPROMEDIOS");
                                    Console.WriteLine("\t---------\n");
                                    string[] array2 = estudiantes();
                                    int y = 0;
                                    foreach (int box in arr5)
                                    {
                                        Console.WriteLine(array2[y]);
                                        Console.WriteLine(box);
                                        y++;
                                    }
                                    Array.Sort(arr5);
                                    Console.WriteLine("\n\tLa nota más baja es de: " + arr5[0]);
                                    Array.Reverse(arr5);
                                    Console.WriteLine("\tLa nota más alta es de: " + arr5[0]);
                                    Console.WriteLine();

                                    flag4 = salir();
                                }
                                break;
                            case 4:
                                flag = salir();
                                exit = flag;
                                break;
                            default:
                                menError();
                                enter();
                                clear();
                                flag = true;
                                break;
                        }
                    }
                }catch (Exception e){
                    Console.WriteLine("\n\t>>>SELECCION INVALIDA, DATO ERRONEO");
                    Console.WriteLine("\tPresione ENTER para regresar");
                    enter();
                    clear();
                }
            } while (exit == true);
        }

        public static int menu() {
            Console.WriteLine("   NOTAS DE ESTUDIANTES");
            Console.WriteLine("\t<<<MENÚ>>>");
            Console.WriteLine("------------------------\n");
            Console.WriteLine("1.Ver a los estudiantes");
            Console.WriteLine("2.Ingresar notas");
            Console.WriteLine("3.Ver notas");
            Console.WriteLine("4.Salir");
            int opcion = int.Parse(getInput("\t>>>Por favor ingrese la opción: "));
            return opcion;
        }
        //Estudiantes
        public static string[] estudiantes() {
        //public static void estudiantes() { 
            string[] names = new string[10];
            names[0] = "Juan Camaney";
            names[1] = "Mariska Hargitay";
            names[2] = "Samuel Jackson";
            names[3] = "Earl Jones";
            names[4] = "Jared Leto";
            names[5] = "Hugh Laurie";
            names[6] = "Antony Starr";
            names[7] = "Hilary Swank";
            names[8] = "Gabrielle Union";
            names[9] = "Christoph Waltz";
            return names;
            

        }
        //Imprime a los estudiantes
        public static string imprimir() {
            Console.WriteLine("\t\tEstudiantes de Ingeniería en electrónica 2016\n");
            foreach (string a in estudiantes())
            {
                Console.WriteLine(a);
            }
            return "";
        }
        //Menu para salir
        public static int menuSalir() {
            Console.WriteLine("\n¿Quiéres salir?");
            Console.WriteLine("1.Si\n2.No");
            int opcion = int.Parse(getInput("\t>>>Por favor ingrese la opción: "));
            return opcion;
        }
        private static String getInput(String prompt){
            Console.Write(prompt);
            try{
                return Console.ReadLine();
            }catch(Exception e){
                return "Error Al valor";
            }
        }
        public static bool salir() {
            
            int opcion = menuSalir();
            bool value;
            switch (opcion) {
                case 1:
                    value = false;
                    break;
                case 2:
                    value = true;
                    break;
                default:
                    menError();
                    enter();
                    value = true;
                    break;
            }
            clear();
            return value;
            
        }
        public static void enter() {
            while (Console.ReadKey().Key != ConsoleKey.Enter) ;
        }
        public static void clear() {
            Console.Clear();
        }
        public static string menError() {
            Console.WriteLine("\t > Está opción no existe, presione ENTER para continuar");
            return "";
        }

        
    }
}
